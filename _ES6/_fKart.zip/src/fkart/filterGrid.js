export const filtersGrid = function (filters) {

    for (let filter of filters) {
        if (filter.type == "PRICE") {
            let priceFilter = document.createElement('div')
            let minSelect = document.createElement('select');
            for (let minPrice of filter.values) {
                let minOption = document.createElement('option');
                minOption.value = minPrice.key;
                minOption.innerHTML = minPrice.displayValue;
                minSelect.appendChild(minOption);
            }
            priceFilter.appendChild(minSelect);
            let toSpan = document.createElement('span');
            toSpan.innerHTML = 'to';
            priceFilter.appendChild(toSpan);
            let maxSelect = document.createElement('select');
            for (let maxPrice of filter.values) {
                let maxOption = document.createElement('option');
                maxOption.value = maxPrice.key;
                maxOption.innerHTML = maxPrice.displayValue;
                maxSelect.appendChild(maxOption);
            }
            priceFilter.appendChild(maxSelect);
            document.getElementById('priceFilter').appendChild(priceFilter);
        }
        if (filter.type == "COLOUR") {
            let colorFilter = '<div> <ul>'
            for (let color of filter.values) {
                colorFilter +=
                    '<li>' +
                    '<input type="checkbox">' +
                    '<span class="color-box" style="background:' + color.color + '"> </span>' +
                    '<span class="color-title">' + color.title + '</span>' +
                    '</li>'
            } +
            '</ul> </div>';
            document.getElementById('colorFilter').innerHTML = colorFilter;
        }
    }
}

export default filtersGrid;