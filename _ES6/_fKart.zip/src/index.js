import "./main.css";
import "normalize.css";
import {
    getProductData,
    getFilterData
} from "./fkart/services";

import {
    productsGrid
} from "./fkart/productsGrid";

import {
    filtersGrid
} from "./fkart/filterGrid";


getProductData().then(data => {
    console.log(data);
    // Get List of Products
    let productsDOM = productsGrid(data);

    let listOfProducts = document.createElement('div');
    listOfProducts.className = "products-list";
    listOfProducts.innerHTML = productsDOM;
    document.getElementById('productsGrid').appendChild(listOfProducts);
});

getFilterData().then(data => {
    console.log(data);
    // Get List of Products
    let productsDOM = filtersGrid(data);

    let filtersGridDOM = document.createElement('div');
    filtersGridDOM.className = "productsgrid-list";
    filtersGridDOM.innerHTML = productsDOM;
    document.getElementById('prodFilterGrid').appendChild(filtersGridDOM);
});

function colourFilter(color) {
    getProductData().then(data => {
        let productList = data.filter(data => data.colour.color == color);
        let productsDOM = productsGrid(data);

        let listOfProducts = document.createElement('div');
        listOfProducts.className = "products-list";
        listOfProducts.innerHTML = productsDOM;
        document.getElementById('productsGrid').appendChild(listOfProducts);
    });
}

const slotClicked = (color) => {
    getProductData().then(data => {
        let productList = data.filter(data => data.colour.color == color);
        let productsDOM = productsGrid(data);

        let listOfProducts = document.createElement('div');
        listOfProducts.className = "products-list";
        listOfProducts.innerHTML = productsDOM;
        document.getElementById('productsGrid').appendChild(listOfProducts);
    });
}